# Ejemplos de divisores de frecuencia

Estos son ejemplos de divisores de frecuencia.

Hace falta agregar parámetros para instanciar los módulos
y así poder realizar simulaciones sin gastar tanto timepo
en ellas.
