# Ejemplo de uso de una LUT4

En este ejemplo se implementa una compuerta AND de 2 entradas a través de una LUT4.

* Descarga el ejemplo desde [éste enlace](./and2_lut4.zip)

