# LEDs con contador y memoria RAM

![RTL](./top.png)


Generación del RTL teniendo en cuenta el divisor de frecuencia y desde el top del diseño

```bash
make rtl rtl2png MACROS_SIM= 
```
