# Simulación de contador de 3 bits

![RTL del contador](./counter.png)

## Simulación manual

1. Crear el ejcutable *top.vvp* con iverilog:
```bash
iverilog -o top.vvp counter_tb.v counter.v
```

3. Iniciar la simulación generar resultados
```bash
vvp top.vvp
```
Para finalizar simulación: `> finsih`


Al crear un archivo `./file_list.txt` puede crear el objeto de simulación como

```bash
iverilog -o top.vvp -c file_list.txt
vvp top.vvp
```

## Simulación a través de Makefile

```bash
make help       -> Menú de ayuda
make sim        -> Simular diseño
make wave       -> Ver simulación en gtkwave
make rtl        -> Crear RTL
```
